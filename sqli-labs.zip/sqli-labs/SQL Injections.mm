<map version="0.9.0">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node CREATED="1324136400104" ID="ID_1494913344" MODIFIED="1337286917597" TEXT="SQL Injections">
<node CREATED="1324136425237" HGAP="-20" ID="ID_903641389" MODIFIED="1337260013781" POSITION="right" TEXT="Less-2" VSHIFT="25">
<icon BUILTIN="pencil"/>
<node CREATED="1324136506469" ID="ID_456038241" MODIFIED="1324137982001" TEXT="GET - Error based - Intiger based" VSHIFT="12">
<icon BUILTIN="penguin"/>
</node>
</node>
<node CREATED="1324136501788" HGAP="-1" ID="ID_1198941000" MODIFIED="1337259272341" POSITION="right" TEXT="Less - 4" VSHIFT="7">
<icon BUILTIN="pencil"/>
<node CREATED="1324136690771" HGAP="15" ID="ID_85068748" MODIFIED="1337261429133" TEXT="GET - Error based - Double Quotes - String" VSHIFT="14">
<icon BUILTIN="penguin"/>
</node>
</node>
<node CREATED="1324136429162" HGAP="-14" ID="ID_194436165" MODIFIED="1337260007157" POSITION="left" TEXT="Less-1" VSHIFT="420">
<icon BUILTIN="pencil"/>
<node CREATED="1324137533985" ID="ID_1551007752" MODIFIED="1337260583276" TEXT="GET - Error based - Single quotes - String" VSHIFT="14">
<icon BUILTIN="penguin"/>
</node>
</node>
<node CREATED="1324136441860" HGAP="-1" ID="ID_351889515" MODIFIED="1337259128893" POSITION="left" TEXT="Less - 3" VSHIFT="5">
<icon BUILTIN="pencil"/>
<node CREATED="1324137615576" HGAP="17" ID="ID_201265776" MODIFIED="1337261025131" TEXT="GET - Error based - Single quotes with twist - string" VSHIFT="15">
<icon BUILTIN="penguin"/>
</node>
</node>
<node CREATED="1324137319383" HGAP="11" ID="ID_853573586" MODIFIED="1337259267805" POSITION="right" TEXT="Less - 6" VSHIFT="-3">
<icon BUILTIN="pencil"/>
<node CREATED="1324137333904" HGAP="17" ID="ID_429405468" MODIFIED="1337262992561" TEXT="GET - Double Injection - Double Quotes - String" VSHIFT="14">
<icon BUILTIN="penguin"/>
</node>
</node>
<node CREATED="1324137466548" HGAP="3" ID="ID_117543297" MODIFIED="1337259125381" POSITION="left" TEXT="Less - 5" VSHIFT="4">
<icon BUILTIN="pencil"/>
<node CREATED="1324137630177" ID="ID_831348399" MODIFIED="1337262888013" TEXT="GET - Double Injection - Single Quotes - String" VSHIFT="16">
<icon BUILTIN="penguin"/>
</node>
</node>
<node CREATED="1324137707627" HGAP="15" ID="ID_1410936587" MODIFIED="1337259444157" POSITION="right" TEXT="Less - 8" VSHIFT="-1">
<icon BUILTIN="pencil"/>
<node CREATED="1324137874201" HGAP="21" ID="ID_1403477223" MODIFIED="1337268888690" TEXT="GET - Blind - Boolian Based - Single Quotes" VSHIFT="18">
<icon BUILTIN="penguin"/>
</node>
</node>
<node CREATED="1324137711332" HGAP="12" ID="ID_824569291" MODIFIED="1337259428533" POSITION="left" TEXT="Less - 7" VSHIFT="-3">
<icon BUILTIN="pencil"/>
<node CREATED="1324137896185" HGAP="16" ID="ID_1830668257" MODIFIED="1337263959999" TEXT="GET - Dump into outfile - String" VSHIFT="17">
<icon BUILTIN="penguin"/>
</node>
</node>
<node CREATED="1324137714364" HGAP="16" ID="ID_188847598" MODIFIED="1337260382565" POSITION="right" TEXT="Less - 10" VSHIFT="4">
<icon BUILTIN="pencil"/>
<node CREATED="1324137878394" HGAP="18" ID="ID_1523865604" MODIFIED="1337268746821" TEXT="GET - Blind - Time based - double quotes" VSHIFT="17">
<icon BUILTIN="penguin"/>
</node>
</node>
<node CREATED="1324137717348" HGAP="14" ID="ID_1523381996" MODIFIED="1337259640581" POSITION="left" TEXT="Less - 9" VSHIFT="-13">
<icon BUILTIN="pencil"/>
<node CREATED="1324137890129" HGAP="16" ID="ID_1287016606" MODIFIED="1337268758172" TEXT="GET - Blind - Time based. -  Single Quotes" VSHIFT="17">
<icon BUILTIN="penguin"/>
</node>
</node>
<node CREATED="1337259455429" HGAP="14" ID="ID_466917223" MODIFIED="1337260379429" POSITION="right" TEXT="Less - 12" VSHIFT="8">
<icon BUILTIN="pencil"/>
<node CREATED="1337259473888" ID="ID_962658043" MODIFIED="1337277045257" TEXT="POST - Error Based - Double quotes- String - with twist" VSHIFT="21">
<icon BUILTIN="penguin"/>
</node>
</node>
<node CREATED="1337259571346" HGAP="13" ID="ID_808975697" MODIFIED="1337286783282" POSITION="left" TEXT="Less - 11" VSHIFT="-9">
<icon BUILTIN="pencil"/>
<node CREATED="1337259649440" HGAP="19" ID="ID_190240143" MODIFIED="1337276981782" TEXT="POST - Error Based - Single quotes- String" VSHIFT="13">
<icon BUILTIN="penguin"/>
</node>
</node>
<node CREATED="1337259743007" HGAP="25" ID="ID_889999997" MODIFIED="1337260376149" POSITION="right" TEXT="Less - 14" VSHIFT="2">
<icon BUILTIN="pencil"/>
<node CREATED="1337260036723" HGAP="23" ID="ID_470682976" MODIFIED="1337277271837" TEXT="POST - Double Injection - Single quotes- String - with twist" VSHIFT="21">
<icon BUILTIN="penguin"/>
</node>
</node>
<node CREATED="1337259745713" HGAP="8" ID="ID_1208232472" MODIFIED="1337286798090" POSITION="left" TEXT="Less - 13" VSHIFT="-13">
<icon BUILTIN="pencil"/>
<node CREATED="1337260017152" ID="ID_778159028" MODIFIED="1337277245068" TEXT="POST - Double Injection - Single quotes- String - with twist" VSHIFT="15">
<icon BUILTIN="penguin"/>
</node>
</node>
<node CREATED="1337259760351" HGAP="18" ID="ID_1236630160" MODIFIED="1337260373957" POSITION="right" TEXT="Less - 16" VSHIFT="4">
<icon BUILTIN="pencil"/>
<node CREATED="1337260042429" ID="ID_1831469301" MODIFIED="1337285075909" TEXT="POST - Blind- Boolian/Time Based - Double quotes" VSHIFT="16">
<icon BUILTIN="penguin"/>
</node>
</node>
<node CREATED="1337259762765" HGAP="-2" ID="ID_1521023455" MODIFIED="1337286806755" POSITION="left" TEXT="Less - 15" VSHIFT="-9">
<icon BUILTIN="pencil"/>
<node CREATED="1337260056500" ID="ID_1620579356" MODIFIED="1337285063938" TEXT="POST - Blind- Boolian/time Based - Single quotes" VSHIFT="15">
<icon BUILTIN="penguin"/>
</node>
</node>
<node CREATED="1337259768974" HGAP="13" ID="ID_1264770325" MODIFIED="1337286648840" POSITION="right" TEXT="Less - 18" VSHIFT="-1">
<icon BUILTIN="pencil"/>
<node CREATED="1337260049111" HGAP="22" ID="ID_1399680041" MODIFIED="1337293102391" TEXT="POST - Header Injection - Uagent field - Error based" VSHIFT="18">
<icon BUILTIN="penguin"/>
</node>
</node>
<node CREATED="1337259771723" HGAP="-10" ID="ID_371433913" MODIFIED="1337286802127" POSITION="left" TEXT="Less - 17" VSHIFT="-9">
<icon BUILTIN="pencil"/>
<node CREATED="1337260061967" HGAP="23" ID="ID_1507876679" MODIFIED="1337286574063" TEXT="POST - Update Query- Error Based - String" VSHIFT="15">
<icon BUILTIN="penguin"/>
</node>
</node>
<node CREATED="1337286635272" HGAP="8" ID="ID_1025670211" MODIFIED="1337287024986" POSITION="right" TEXT="Less-20" VSHIFT="5">
<icon BUILTIN="pencil"/>
<node CREATED="1337286752435" ID="ID_586679887" MODIFIED="1337342690566" TEXT="POST - Cookie injections - Uagent field - error based." VSHIFT="20">
<icon BUILTIN="penguin"/>
</node>
</node>
<node CREATED="1337286664875" HGAP="-16" ID="ID_622646021" MODIFIED="1337287122201" POSITION="left" TEXT="Less-19" VSHIFT="-1">
<icon BUILTIN="pencil"/>
<node CREATED="1337286733038" HGAP="19" ID="ID_1658696559" MODIFIED="1337344524751" TEXT="POST - Header Injection - Referer field - Error based" VSHIFT="18">
<icon BUILTIN="penguin"/>
</node>
</node>
<node CREATED="1337286811307" HGAP="-13" ID="ID_675480068" MODIFIED="1337287057328" POSITION="right" TEXT="Less-22" VSHIFT="-184">
<icon BUILTIN="pencil"/>
<node CREATED="1337287084942" HGAP="21" ID="ID_471107631" MODIFIED="1337342719626" TEXT="Future Editions" VSHIFT="18">
<icon BUILTIN="penguin"/>
</node>
</node>
<node CREATED="1337286920172" HGAP="-35" ID="ID_38136745" MODIFIED="1337287052421" POSITION="left" TEXT="Less-21" VSHIFT="-500">
<icon BUILTIN="pencil"/>
<node CREATED="1337287063065" HGAP="16" ID="ID_58695417" MODIFIED="1337344443790" TEXT="POST- Dump into outfile - String" VSHIFT="18">
<icon BUILTIN="penguin"/>
</node>
</node>
</node>
</map>
